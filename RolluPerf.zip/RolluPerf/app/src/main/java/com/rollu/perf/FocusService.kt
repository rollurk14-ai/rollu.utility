package com.rollu.perf

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

/**
 * Battery Saver+ enforcement. When saver mode is on and the app in front is not on the
 * allowed list, send the user back to the home screen. Non-root apps cannot truly disable
 * other apps, so this blocks them from being used instead.
 */
class FocusService : AccessibilityService() {
    private var lastToast = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!Store.saverOn(this)) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg in Store.allowed(this) || pkg in alwaysAllowed()) return

        performGlobalAction(GLOBAL_ACTION_HOME)
        val now = SystemClock.elapsedRealtime()
        if (now - lastToast > 2000) {
            lastToast = now
            Toast.makeText(this, "Blocked by Rollu Perf saver", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onInterrupt() {}

    private fun alwaysAllowed(): Set<String> {
        val s = mutableSetOf(
            packageName, "android", "com.android.systemui", "com.android.settings",
            "com.android.phone", "com.android.server.telecom", "com.android.incallui",
            "com.google.android.dialer", "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
        )
        packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName?.let { s += it }
        getSystemService(InputMethodManager::class.java)?.enabledInputMethodList
            ?.forEach { s += it.packageName }
        getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s += it }
        return s
    }
}
