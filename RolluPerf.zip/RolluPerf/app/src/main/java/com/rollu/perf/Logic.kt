package com.rollu.perf

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import java.io.File

/** Tiny SharedPreferences wrapper. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("rollu", Context.MODE_PRIVATE)

    fun allowed(c: Context): Set<String> = p(c).getStringSet("allowed", emptySet()) ?: emptySet()
    fun setAllowed(c: Context, s: Set<String>) = p(c).edit().putStringSet("allowed", s.toSet()).apply()

    fun games(c: Context): Set<String> = p(c).getStringSet("games", emptySet()) ?: emptySet()
    fun setGames(c: Context, s: Set<String>) = p(c).edit().putStringSet("games", s.toSet()).apply()

    fun saverOn(c: Context): Boolean = p(c).getBoolean("saver", false)
    fun setSaverOn(c: Context, v: Boolean) = p(c).edit().putBoolean("saver", v).apply()
}

data class AppItem(val pkg: String, val label: String, val icon: Drawable)

data class Snap(
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val ramFreeMb: Long,
    val cores: List<Pair<Long?, Long?>>, // current kHz, max kHz
    val battery: Int,
    val tempC: Float,
    val charging: Boolean,
    val storageUsedGb: Float,
    val storageTotalGb: Float,
)

object Stats {
    private fun readLong(path: String): Long? =
        try { File(path).readText().trim().toLong() } catch (e: Exception) { null }

    fun read(c: Context): Snap {
        val am = c.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val totalMb = mi.totalMem / 1048576
        val freeMb = mi.availMem / 1048576

        val cores = (0 until Runtime.getRuntime().availableProcessors()).map { i ->
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            readLong(base + "scaling_cur_freq") to readLong(base + "cpuinfo_max_freq")
        }

        val bi = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val sf = StatFs(Environment.getDataDirectory().path)
        val totalGb = sf.totalBytes / 1073741824f
        val usedGb = (sf.totalBytes - sf.availableBytes) / 1073741824f

        return Snap(
            ramUsedMb = totalMb - freeMb, ramTotalMb = totalMb, ramFreeMb = freeMb,
            cores = cores, battery = level * 100 / scale, tempC = temp, charging = charging,
            storageUsedGb = usedGb, storageTotalGb = totalGb,
        )
    }
}

object Perf {
    fun launchableApps(c: Context): List<AppItem> {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .filter { it.pkg != c.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    /** Stops background processes of every launchable app except [keep]. Returns how many apps were asked to stop. */
    fun killBackground(c: Context, keep: Set<String>): Int {
        val am = c.getSystemService(ActivityManager::class.java)
        var n = 0
        for (app in launchableApps(c)) {
            if (app.pkg in keep) continue
            am.killBackgroundProcesses(app.pkg)
            n++
        }
        return n
    }

    fun hasDnd(c: Context): Boolean =
        c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    fun setDnd(c: Context, on: Boolean) {
        if (!hasDnd(c)) return
        c.getSystemService(NotificationManager::class.java).setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }

    fun focusServiceEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains(c.packageName + "/" + FocusService::class.java.name)
    }

    /** Free RAM, silence notifications, launch the game. */
    fun boostAndLaunch(c: Context, pkg: String): String {
        val freed = killBackground(c, setOf(pkg))
        setDnd(c, true)
        val launch = c.packageManager.getLaunchIntentForPackage(pkg)
        return if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(launch)
            "Boosted: stopped $freed background apps"
        } else "Could not open that game"
    }
}
