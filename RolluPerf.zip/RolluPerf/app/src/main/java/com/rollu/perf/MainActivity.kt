package com.rollu.perf

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Black = Color(0xFF000000)
private val Panel = Color(0xFF110A1C)
private val Purple = Color(0xFFB266FF)
private val DeepPurple = Color(0xFF7B2FF7)
private val Dim = Color(0xFFB8A9CC)
private val Track = Color(0xFF2A1745)
private val Edge = Color(0xFF3B1F66)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple, onPrimary = Black, secondary = DeepPurple,
                    background = Black, surface = Panel,
                    onBackground = Color.White, onSurface = Color.White,
                )
            ) { Root() }
        }
    }
}

@Composable
fun Root() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val names = listOf("Stats", "Saver", "Game")
    val icons = listOf("⚡", "🔋", "🎮")
    Scaffold(
        containerColor = Black,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0B0612)) {
                names.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icons[i], fontSize = 20.sp) },
                        label = { Text(n) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = DeepPurple,
                            selectedTextColor = Purple, unselectedTextColor = Dim,
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> StatsScreen()
                1 -> SaverScreen()
                else -> GameScreen()
            }
        }
    }
}

// ---------- shared pieces ----------

@Composable
fun Header(title: String, sub: String) {
    Column(Modifier.padding(bottom = 4.dp)) {
        Text(title, color = Purple, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Text(sub, color = Dim, fontSize = 13.sp)
    }
}

@Composable
fun RCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Panel)
            .border(1.dp, Edge, RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
        content()
    }
}

@Composable
fun Meter(label: String, value: String, frac: Float) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Dim, fontSize = 14.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { frac.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = Purple, trackColor = Track,
        )
    }
}

@Composable
fun PurpleButton(text: String, modifier: Modifier = Modifier.fillMaxWidth(), onClick: () -> Unit) {
    Button(
        onClick = onClick, modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = DeepPurple, contentColor = Color.White),
    ) { Text(text, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
}

@Composable
fun AppRow(app: AppItem, checked: Boolean, onToggle: () -> Unit) {
    val img = remember(app.pkg) { app.icon.toBitmap(96, 96).asImageBitmap() }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(img, contentDescription = null, modifier = Modifier.size(40.dp))
        Spacer(Modifier.width(12.dp))
        Text(app.label, color = Color.White, modifier = Modifier.weight(1f))
        Checkbox(
            checked = checked, onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(checkedColor = Purple, checkmarkColor = Black, uncheckedColor = Dim),
        )
    }
}

@Composable
fun rememberApps(): List<AppItem> {
    val ctx = LocalContext.current
    val apps by produceState(emptyList<AppItem>()) {
        value = withContext(Dispatchers.IO) { Perf.launchableApps(ctx) }
    }
    return apps
}

// ---------- Stats / boost ----------

@Composable
fun StatsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var s by remember { mutableStateOf<Snap?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            s = withContext(Dispatchers.IO) { Stats.read(ctx) }
            delay(1000)
        }
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Header("ROLLU PERF", "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}")

        PurpleButton("⚡ BOOST NOW") {
            scope.launch {
                val before = withContext(Dispatchers.IO) { Stats.read(ctx).ramFreeMb }
                val n = withContext(Dispatchers.IO) { Perf.killBackground(ctx, emptySet()) }
                delay(800)
                val after = withContext(Dispatchers.IO) { Stats.read(ctx).ramFreeMb }
                val gained = (after - before).coerceAtLeast(0)
                Toast.makeText(ctx, "Stopped $n apps · +$gained MB free", Toast.LENGTH_LONG).show()
            }
        }

        s?.let { snap ->
            RCard("MEMORY") {
                Meter("RAM", "${snap.ramUsedMb} / ${snap.ramTotalMb} MB", snap.ramUsedMb / snap.ramTotalMb.toFloat())
                Text("Free: ${snap.ramFreeMb} MB", color = Dim, fontSize = 12.sp)
            }
            RCard("CPU · ${snap.cores.size} CORES") {
                snap.cores.forEachIndexed { i, (cur, max) ->
                    if (cur != null && max != null && max > 0) {
                        Meter("Core $i", "${cur / 1000} MHz", cur / max.toFloat())
                    } else {
                        Text("Core $i · frequency hidden by this phone", color = Dim, fontSize = 13.sp)
                    }
                }
            }
            RCard("BATTERY") {
                Meter("Level", "${snap.battery}%${if (snap.charging) " ⚡ charging" else ""}", snap.battery / 100f)
                Text("Temperature: ${"%.1f".format(snap.tempC)} °C", color = Dim, fontSize = 13.sp)
            }
            RCard("STORAGE") {
                Meter(
                    "Internal", "${"%.1f".format(snap.storageUsedGb)} / ${"%.0f".format(snap.storageTotalGb)} GB",
                    snap.storageUsedGb / snap.storageTotalGb,
                )
            }
        }
    }
}

// ---------- Battery saver+ ----------

@Composable
fun SaverScreen() {
    val ctx = LocalContext.current
    val apps = rememberApps()
    var on by remember { mutableStateOf(Store.saverOn(ctx)) }
    var sel by remember { mutableStateOf(Store.allowed(ctx)) }
    var serviceOn by remember { mutableStateOf(Perf.focusServiceEnabled(ctx)) }
    LaunchedEffect(Unit) {
        while (true) { serviceOn = Perf.focusServiceEnabled(ctx); delay(1000) }
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Header("BATTERY SAVER+", "Only the apps you pick can be opened") }
        item {
            RCard("SAVER MODE") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (on) "ON" else "OFF", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("${sel.size} apps allowed", color = Dim, fontSize = 12.sp)
                    }
                    Switch(
                        checked = on,
                        onCheckedChange = { v ->
                            on = v
                            Store.setSaverOn(ctx, v)
                            if (v) {
                                val n = Perf.killBackground(ctx, sel)
                                Toast.makeText(ctx, "Saver on · stopped $n apps", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = SwitchDefaults.colors(checkedTrackColor = DeepPurple, checkedThumbColor = Purple),
                    )
                }
                if (!serviceOn) {
                    Text(
                        "Step needed: enable \"Rollu Perf Saver\" in Accessibility so apps can be blocked.",
                        color = Color(0xFFFFB86B), fontSize = 13.sp,
                    )
                    PurpleButton("OPEN ACCESSIBILITY SETTINGS") {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                } else {
                    Text("Blocking service is active ✓", color = Purple, fontSize = 13.sp)
                }
                Text(
                    "Phone, keyboard, launcher, Settings and Rollu Perf are always allowed. Turn the switch off here to get everything back.",
                    color = Dim, fontSize = 12.sp,
                )
            }
        }
        item {
            PurpleButton("OPEN SYSTEM BATTERY SAVER") {
                ctx.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        item { Text("ALLOWED APPS", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp) }
        items(apps, key = { it.pkg }) { app ->
            AppRow(app, app.pkg in sel) {
                sel = if (app.pkg in sel) sel - app.pkg else sel + app.pkg
                Store.setAllowed(ctx, sel)
            }
        }
    }
}

// ---------- Game booster ----------

@Composable
fun GameScreen() {
    val ctx = LocalContext.current
    val apps = rememberApps()
    var sel by remember { mutableStateOf(Store.games(ctx)) }
    var dnd by remember { mutableStateOf(Perf.hasDnd(ctx)) }
    LaunchedEffect(Unit) {
        while (true) { dnd = Perf.hasDnd(ctx); delay(1000) }
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Header("GAME BOOSTER", "Free RAM · mute notifications · launch") }
        item {
            RCard("DO NOT DISTURB") {
                if (dnd) {
                    Text("Access granted ✓ Notifications are silenced while you play.", color = Purple, fontSize = 13.sp)
                } else {
                    Text("Allow Do Not Disturb access so pop-ups don't interrupt your game.", color = Color(0xFFFFB86B), fontSize = 13.sp)
                    PurpleButton("GRANT ACCESS") {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
        }
        val picked = apps.filter { it.pkg in sel }
        items(picked, key = { "go_" + it.pkg }) { g ->
            PurpleButton("🚀 BOOST & PLAY ${g.label.uppercase()}") {
                Toast.makeText(ctx, Perf.boostAndLaunch(ctx, g.pkg), Toast.LENGTH_SHORT).show()
            }
        }
        item {
            OutlinedButton(
                onClick = {
                    Perf.setDnd(ctx, false)
                    Toast.makeText(ctx, "Game mode ended", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
            ) { Text("END GAME MODE (notifications back)", color = Purple) }
        }
        item { Text("PICK YOUR GAMES", color = Purple, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp) }
        items(apps, key = { it.pkg }) { app ->
            AppRow(app, app.pkg in sel) {
                sel = if (app.pkg in sel) sel - app.pkg else sel + app.pkg
                Store.setGames(ctx, sel)
            }
        }
    }
}
