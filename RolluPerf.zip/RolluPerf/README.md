# Rollu Perf

Black and purple performance app for Android 8.0+.

- **Stats**: live RAM, per-core CPU frequency, battery level and temperature, storage, plus a one-tap Boost.
- **Saver**: pick the apps you allow. With saver on, every other app sends you back to the home screen.
- **Game**: pick your games, then "Boost & Play" frees RAM, mutes notifications and launches the game.

## Build the APK

**Option A: Android Studio**
1. Open this folder in Android Studio and let it sync.
2. Build > Build APK(s). The file is `app/build/outputs/apk/debug/app-debug.apk`.

**Option B: no install, GitHub Actions**
1. Push this folder to a new GitHub repo (branch `main`).
2. Open the Actions tab, wait for "Build APK", download the `rollu-perf-apk` artifact.

Install the APK on your phone (allow "install unknown apps" for your browser/files app).

## First run
- Saver tab: tap "Open accessibility settings", enable **Rollu Perf Saver**.
- Game tab: tap "Grant access" for Do Not Disturb.
